library("testthat")
test_check("tutorial")
